package pdc.project.entity;

public class Bonus {
}
